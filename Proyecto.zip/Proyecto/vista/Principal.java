package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import javax.swing.JTextField;

public class Principal extends JFrame {

	private JLayeredPane contentPane;
	private JTextField IDCampoTexto;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1263, 623);
		contentPane = new JLayeredPane();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		IDCampoTexto = new JTextField();
		IDCampoTexto.setBorder(null);
		IDCampoTexto.setBackground(new Color(20, 20, 20));
		IDCampoTexto.setBounds(556, 220, 190, 26);
		contentPane.add(IDCampoTexto);
		IDCampoTexto.setColumns(10);
		
		JLabel lblPw = new JLabel("PW");
		lblPw.setForeground(Color.WHITE);
		lblPw.setFont(new Font("Power Red and Green", Font.PLAIN, 15));
		lblPw.setBounds(517, 254, 16, 14);
		contentPane.add(lblPw);
		
		JLabel textID = new JLabel("ID");
		textID.setForeground(new Color(255, 255, 255));
		textID.setFont(new Font("Power Red and Green", Font.PLAIN, 15));
		textID.setBounds(517, 229, 16, 14);
		contentPane.add(textID);
		
		JLabel textLogin = new JLabel("Login");
		textLogin.setFont(new Font("Power Red and Green", Font.PLAIN, 17));
		textLogin.setForeground(new Color(255, 255, 255));
		textLogin.setBounds(603, 181, 57, 26);
		contentPane.add(textLogin);
		
		JLabel fondoLogin = new JLabel("");
		fondoLogin.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(238, 238, 238), new Color(238, 238, 238), new Color(0, 0, 0), new Color(0, 0, 0)));
		fondoLogin.setOpaque(true);
		fondoLogin.setForeground(Color.WHITE);
		fondoLogin.setBackground(new Color(51, 51, 51));
		fondoLogin.setBounds(512, 181, 238, 127);
		contentPane.add(fondoLogin);
		
		JLabel fondoVentana = new JLabel("");
		fondoVentana.setIcon(new ImageIcon("C:\\Users\\USER\\Desktop\\CARPETAS Y COSAS\\Proyecto\\loginImagen2.jpg"));
		fondoVentana.setBounds(0, 0, 1247, 585);
		contentPane.add(fondoVentana);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBorder(null);
		textField_2.setBackground(new Color(20, 20, 20));
		textField_2.setBounds(556, 250, 190, 26);
		contentPane.add(textField_2);
	}
}
