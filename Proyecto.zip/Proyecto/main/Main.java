package main;

import java.awt.EventQueue;

import bbdd.conexion;
import vista.Principal;

public class Main {
	public static void main(String[] args) {
	
		
	}
}
